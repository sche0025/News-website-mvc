﻿$(function () {
    $("#yearPub").datepicker({ dateFormat: 'yy' });
});